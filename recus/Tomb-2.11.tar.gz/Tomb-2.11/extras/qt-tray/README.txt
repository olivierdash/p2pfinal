
Build with 'qmake' and then 'make'

Requires QT version 5.4 or above

To install copy the binary in your PATH
then all contents of pixmaps to /usr/share/pixmaps
and all contents of i18n to /usr/share/i18n

The prefix /usr/local may be preferred if ever packaged.

