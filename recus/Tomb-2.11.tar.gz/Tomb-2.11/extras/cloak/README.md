# Cloakify steganography into text files

Original repo: https://github.com/asrabon/Cloakify-3
